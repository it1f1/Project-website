<?php 

	    if (isset($_POST['submit'])) 
	    {
	        
	        $age = $_POST['age'];
	       
	     

	          

	      if (!filter_var($age, FILTER_VALIDATE_INT) && (!(empty($age))) ) 
		{

			$ageError= "please enter an integer value";

		}

		if (empty($_POST['age'])) 
		{

			$ageError= "please enter your correct age";

		}


	       

	        
	    }

?>


<html>
	<head>
		<title></title>
	</head>
	<body>
		<?php
			// if (isset($_POST['submit'])) 
			// {
			// 	$email = $_POST['email'];
			// 	$phone = $_POST['phone-number'];
			// 	$phone_len = strlen($phone);

			// 	// Remove all illegal characters from email
			// 	$email = filter_var($email, FILTER_SANITIZE_EMAIL);
				
			// 	if(!filter_var($email,FILTER_VALIDATE_EMAIL) )
			// 	{

			// 		$emailError= "please enter an appropriate mail";
					 

			// 	}else;

			// 	echo '<br>';

			// 	if ( ($phone_len > 13) || (!is_numeric($phone)) ) 
			// 	{

			// 		echo "Enter a valid number and should not be more than 13";

			// 	}else echo "Good";;
				
			// }
		?>



	</body>
</html>

