<?php

    // if (isset($_POST['submit']))
    // {
    //             $email  = $_POST['email'];//get the mail
    //             $phone = $_POST['phone-number'];//get the tel phone number
    //             $phone_len = strlen($phone);//get the length of the phone number

    //             // Remove all illegal characters from email
    //             $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    //         if (!filter_var($email,FILTER_VALIDATE_EMAIL)) //to check if it is not in an email format
    //         {

    //             $emailError= "please enter an appropriate mail";

    //         }
    //         if ( ($phone_len > 13) || (!is_numeric($phone)) )
    //         {

    //                 $telError = "Enter an appropriate number";

    //         }

    //         else;


    // }
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="Stylesheet.css"/>
  <title>Emmen Tech University</title>
</head>

<body>
  <div id="Container">

    <div class="Logo">
      <img src="Images/LogoMakr_26K23H.png">
    </div>
    <div class="Menu">

      <ul>
        <li class="menu">Home</li>
        <li class="menu">About Us</li>
        <li class="menu">Our Programs</li>
        <li class="menu">Contact</li>
        <li class="menu">
          <select name="Language">
          <option value="English">EN</option>
          <option value="Nederlands">NL</option>
        </select>
      </li>

      </ul>

    </div>
    <div class="header">
      <h1>Emmen Tech <br> University</h1>
    </div>

    <h3 class="For">For Higher Learning</h3>

    <div class="container-fluid">
  <h2></h2>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="images/bank.jpeg" alt="Los Angeles" style="width:100%; height:500px;">
      </div>

      <div class="item">
        <img src="images/bank.jpeg" alt="Chicago" style="width:100%; height:500px;">
      </div>

      <div class="item">
        <img src="images/Coding.jpeg" alt="New york" style="width:100%; height:500px;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

    <!--<img class="frontImage" src="Images/college.jpeg" alt="Meeting" width="1300">-->

    <hr>

    <h1>Available Programs</h1>

    <p>What we provide</p>

    <div class="Programs">

      <div class="Picture">
        <img src="Images/Heli.jpg" alt="Html" height="100%" width="100%">
      </div>
      <div class="Text">
        <h3>Banking Insurance</h3>
        <p>Within Banking & Insurance you will be trained as a financial advisor
           and after that you can work at a bank, an insurer or a financial
           advisory office. As a financial advisor you have a sense of numbers
           and you know how to communicate the figures to others in a practical
           and clear way. </p>
      </div>
      <div class="Picture">
        <img src="Images/flight.jpeg" alt="Html" height="100%" width="100%">
      </div>

      <!-- <div class="Text">
        <h3>Helicopter Maintenance</h3>
        <p>My money's in that office, right? If she start giving me some bullshit
           about it ain't there, and we got to go someplace else and get it, I'm
           gonna shoot you in the head then and there. </p>
      </div> -->


      <div class="Text">
        <h3>Helicopter Maintenance</h3>
        <p>The Mechanics Type Rating course is designed to provide mechanics
          technicians with the knowledge and necessary skills to maintain airframe,
          helicopter mechanical systems, rotors, transmissions, and power plants of
          the NH 90 NFH.
</p>
      </div>

      <div class="Picture">
        <img src="Images/bank.jpeg" alt="Html" height="100%" width="100%">
      </div>

      <div class="Text">
        <h3>Flight Engineering</h3>
        <p>Flight engineers assist pilots with communication during flight and
          also make minor repairs to planes. Read further to learn about degree
          programs in related areas like aviation maintenance technology. </p>
      </div>
      </div>

      <hr>
      <div class="AboutUs">
        <h1>About Us</h1>

        <p>At Emmen Tech, we revel in a culture of learning by doing. In 30 departments
        across five schools, our students combine analytical rigor with curiosity,
         playful imagination, and an appetite for solving the hardest problems in
         service to society.</p>
      </div>

    <img class="frontImage" src="Images/aboutus.jpeg" alt="About">

<!--
    <hr>
    <h1>Contact</h1>
    <br>
    <p>Send us your questions via post or Email.</p> -->
    <!-- <div class="Contact">
        <div class="addressBox">

            <ul>
              <li class="list">NHL Stenden University of Applied Sciences</li>
              <li class="list">Van Schaikweg 94</li>
              <li class="list">7811 KL Emmen</li>
              <li class="list">receptie.emmen@stenden.com</li>
              <li class="list">+31 (0)591 853 100</li>
            </ul>

        </div>

        <div class="Form">

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

                <div class="form-details">

                    <input type="text" name="fname" placeholder="Name *" size="26" required>
                    <input type="email" name="email" placeholder="Email *" size="26" required>
                    <span class="error position-email-error">
                            <?php if(isset($emailError))
                            echo $emailError;?>
                    </span>


                    <input type="text" name="address" placeholder="Address *" size="61" required>

                    <input type="tel" name="phone-number" placeholder="Tel: eg:0234 *" size="61" required>
                    <span class="error position-tel-error">
                        <?php if(isset($telError))
                        echo $telError;?>
                    </span>



                    <textarea rows="8" cols="65" placeholder="Message *" name="message" required></textarea>

                    <input type="submit" name="submit" value="Send">

                </div>

            </form>

        </div>

    </div>
 -->
    </div>





  </div>

</body>

</html>
